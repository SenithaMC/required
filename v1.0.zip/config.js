module.exports = {
  prefix: ';',
  token: 'MTQxNjQyMjk3ODEzNjMwOTc5Mw.GYJXlN.dbkjzjYm-w7GgSaQWQoopnYTEd1-7Vv9WPcQ5g',
  mongoURI: 'mongodb+srv://darknessgmn_db_user:lsYafTHB1pHM9GEH@cluster1.gfsdsam.mongodb.net/?retryWrites=true&w=majority&appName=Cluster1',
  client_id: '1416422978136309793',
  bot_name: 'LWKY',
  ownerId: '1240540042926096406',
  commandCooldown: '10', // in seconds
  giveawayCleanup: {
    enabled: true,
    delay: 24 * 60 * 60 * 1000, // 24 hours in milliseconds
    checkInterval: 60 * 60 * 1000 // Check every hour
  }
};