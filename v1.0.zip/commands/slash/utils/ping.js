const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Check bot latency.',

  async execute(interaction) {
    const reply = await interaction.reply({ content: '🏓 Pinging...', withResponse: true });
    const sent = reply.resource.message;

    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    const wsPing = interaction.client.ws.ping;
    const shardId = interaction.guild ? interaction.guild.shardId : 0;

    const embed = new EmbedBuilder()
      .setColor(0x00FFE7)
      .setDescription(`Average websocket latency: \`${wsPing}ms\``)
      .addFields(
        { name: 'API Latency', value: `\`${wsPing}ms\``, inline: true },
        { name: 'Interaction Latency', value: `\`${latency}ms\``, inline: true }
      )
      .setFooter({ text: `Shard #${shardId}` })
      .setTimestamp();

    await interaction.editReply({ content: null, embeds: [embed] });
  }
};
